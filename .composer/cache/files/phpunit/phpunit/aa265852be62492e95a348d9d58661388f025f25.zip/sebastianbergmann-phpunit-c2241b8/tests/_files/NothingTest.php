<?php
class NothingTest extends PHPUnit_Framework_TestCase
{
    public function testNothing()
    {
    }
}
